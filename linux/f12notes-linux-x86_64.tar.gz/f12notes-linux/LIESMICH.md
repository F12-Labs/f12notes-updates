# F12 Notes – Anleitung

Minimalistischer Texteditor für Logbuch, Tagebuch und Notizen – fortlaufend in **einer einzigen Textdatei**.
Ein leeres Fenster, ein Cursor, sonst nichts. Alles Weitere liegt hinter einer einzigen Taste: **F12**.

Für Windows und Linux, dazu eine Android-App, die dieselbe Notizdatei liest und schreibt (siehe [Android](#android)).

## Starten

- **Windows:** `F12Notes.exe` starten – keine Installation nötig.
- **Linux (Mint, Ubuntu, Debian …, 64 Bit):** `dist/f12notes-linux-x86_64.tar.gz` entpacken und entweder
  `./f12notes` direkt starten oder mit `./install.sh` nach `~/F12Notes/` installieren und ins Startmenü eintragen
  (ohne sudo; zum Aktualisieren einfach erneut ausführen, `./install.sh --entfernen` macht es rückgängig).
  Läuft ab glibc 2.31, also ab Linux Mint 20.
- Beim ersten Start wird `F12Notes.txt` **im Ordner der exe** angelegt und künftig automatisch geladen
  (ist der Ordner nicht beschreibbar, z.B. unter „Programme“, stattdessen in `Dokumente`).
  Auch „Neue Notizdatei …“ schlägt den Ordner der exe vor.
- Andere Datei: F12 → „Andere Notizdatei öffnen“ oder `F12Notes.exe pfad\zur\datei.txt`.
- Portabel (USB-Stick): Liegt eine `F12Notes.txt` neben der exe, wird diese verwendet. Dateien im Ordner der exe
  (oder in Unterordnern) werden relativ zur exe gemerkt – auch zusätzliche Speicherziele (`target = sicherung/kopie.txt`).
  Der ganze Ordner kann daher verschoben oder kopiert werden.
- Autostart: F12 → „Autostart“.

## Updates

F12 Notes sucht einmal täglich still nach einer neuen Version (abschaltbar: F12 → „Täglich nach Updates suchen“).
Gibt es eine, steht „⬆ Update“ in der Titelleiste; F12 → „Update installieren“ lädt sie, prüft die Prüfsumme,
tauscht die Programmdatei aus und öffnet alle Fenster wieder. Manuell: F12 → „Nach Updates suchen“.
Die Versionen liegen öffentlich unter <https://github.com/F12-Labs/f12notes-updates> (Quellcode bleibt privat).

## Mehrere Fenster

Es können mehrere Fenster mit unterschiedlichen Textdateien gleichzeitig offen sein
(jedes Fenster ist ein eigener Programmprozess mit den Einstellungen seiner Datei):

- F12 → „Notizdatei in neuem Fenster öffnen“ bzw. „Neue Notizdatei in neuem Fenster anlegen“.
- Zuletzt geöffnete Dateien erscheinen in der F12-Suche als „Öffnen: name.txt“.
- Jede Datei ist nur einmal offen: Ein zweiter Versuch holt das vorhandene Fenster nach vorn.
- Beim Start werden alle Fenster wiederhergestellt, die zuletzt offen waren
  (abschaltbar: F12 → „Fenster wiederherstellen“). Ein einzeln geschlossenes Fenster kommt nicht wieder;
  „Alle Fenster schließen“ merkt sich alle.

## Notiz auf einem anderen PC öffnen (Cloud / WebDAV)

1. Auf dem ersten PC ein WebDAV-Ziel eintragen (F12 → „Speicherziele anzeigen“ → „+ WebDAV-Ziel hinzufügen“).
   Die Notiz wird ab dann bei jedem Speichern dorthin hochgeladen.
2. Auf dem anderen PC: F12 → „Notiz aus der Cloud (WebDAV) öffnen“, die vollständige Adresse der Datei
   (z.B. `https://cloud.example.de/remote.php/dav/files/NAME/Tagebuch.txt`), Benutzer und Passwort eingeben.
   Die Notiz wird im Ordner der exe angelegt, mit allen Einstellungen, und ab dann ebenfalls in die Cloud gespeichert.
   Ist das Fenster noch leer, wird es weiterverwendet, sonst öffnet sich ein neues.

Liegt beim Eintragen eines WebDAV-Ziels unter der Adresse schon eine Notiz, fragt F12 Notes nach:
Stand aus der Cloud laden (empfohlen), lokalen Stand hochladen oder abbrechen. So wird nichts versehentlich überschrieben.

### Mehrere PCs gleichzeitig (z.B. zuhause und im Büro)

Das **erste** WebDAV-Ziel wird laufend abgeglichen (Einstellung „Cloud-Abgleich“; wird beim Hinzufügen des ersten
Cloud-Ziels automatisch eingeschaltet):

- beim Start (zuerst – erst danach werden Tagesdatum und Cursor gesetzt, so fügt nur der erste PC des Tages
  das Datum ein), nach jedem Speichern, alle 30 Sekunden (einstellbar), beim Zurückkehren ins Fenster und beim Beenden;
- Änderungen des anderen PCs werden zeilenweise mit den eigenen zusammengeführt und erscheinen von selbst;
- wurde auf beiden PCs gleichzeitig dieselbe Zeile geändert, wird **wortweise** zusammengeführt
  (z.B. „[x] Milch“ + „[ ] Milch und Brot“ → „[x] Milch und Brot“). Nur wenn dieselben Wörter unterschiedlich
  geändert wurden, steht die Fassung des anderen PCs **farbig hinterlegt** direkt dahinter (`{konflikt|…}`).
  F12 → „Nächste Konflikt-Markierung“ springt hin; behalten: „Textfarbe entfernen“, verwerfen: löschen;
- im Leerlauf wird nur gefragt, ob sich etwas geändert hat (ETag); übertragen wird nur bei Änderungen;
  Server, die ETags nicht sauber behandeln, werden erkannt – dann wird nur der Inhalt verglichen;
- der Abgleich läuft still im Hintergrund; einziger Hinweis: wenn auf zwei PCs gleichzeitig dieselbe Zeile geändert wurde;
- ohne Verbindung wird lokal weitergeschrieben und beim nächsten Kontakt zusammengeführt.
- die Titelleiste zeigt den Stand: `☁ aktuell`, `☁ wird abgeglichen …`, `☁ Cloud wird geladen …`,
  `☁ offline – Änderungen noch nicht in der Cloud`, `☁ nicht erreichbar`.

Weitere WebDAV-Ziele sind reine Kopien (werden überschrieben, nicht abgeglichen).

## Bedienung

Einfach schreiben. Gespeichert wird automatisch (Autosave, ca. 1 s nach der letzten Eingabe).

**F12** öffnet das globale Suchfeld. Es findet:

| Was | Beispiel-Eingabe |
|---|---|
| Text im Logbuch (Enter springt hin, F3 weiter) | `müller`, Regex: `/\d+ km` |
| Befehle | `ersetzen`, `gehe zu datum`, `export` |
| Einstellungen | `dunkel`, `schrift`, `markdown`, `autosave` |
| Textbausteine | `baustein` |
| Tastenkürzel (auch die Magic-Taste selbst) | `tastenkürzel`, `magic` |

Standard-Tasten (alle änderbar): `Strg+F` Suchfeld · `F3`/`Shift+F3` weitersuchen · `Strg+S` speichern ·
`Strg+Z`/`Strg+Y` · `Strg+D` Datum · `Strg+T` Uhrzeit · `F5` Datum+Uhrzeit · `Strg+B`/`Strg+I` fett/kursiv ·
`F11` Vollbild · `Strg +/-/0` Schriftgröße · `Alt+↑/↓` Zeile verschieben · `Enter` Wortvorschlag übernehmen (mit Leerzeichen), `Tab` ohne Leerzeichen, `Esc` verwerfen ·
Klick auf einen Link öffnet ihn (zum Bearbeiten: daneben klicken oder mit den Pfeiltasten hinein).

## Funktionen

- **Zeitstempel je Zeile:** Jede Zeile führt ihr Änderungsdatum mit. In der Datei steht es als
  `[2026-11-12 08:46:33]` vor der Zeile, im Editor ist es ausgeblendet (einblendbar).
  Beim Ziehen der Scrollleiste wird das Änderungsdatum der angezeigten Stelle eingeblendet.
- **Erscheinungsbild:** Dunkelmodus, Schriftart (Standard: Systemschrift, unter Windows Segoe UI; alle Systemschriften wählbar), Schriftgröße, Zeilenabstand, Rand,
  maximale Textbreite, eigene Farben – alles dauerhaft gespeichert.
- **Markdown-Formatierung** – eine Einstellung mit drei Werten: **ein** (Zeichen wie `#`, `**`, `{rot|…}` sind
  ausgeblendet; Pfeiltasten und Löschen überspringen sie), **aus** (Zeichen sichtbar, keine Formatierung) und
  **in aktueller Zeile** (formatiert, die Zeichen erscheinen nur in der Zeile mit dem Cursor): `# Überschrift`, `**fett**`, `*kursiv*`, `` `Code` ``, `~~durchgestrichen~~`,
  Listen, `> Zitat`, Codeblöcke, Links.
  `[]` oder `[ ]` wird zur Checkbox – am Zeilenanfang, nach `- ` oder mitten im Text
  (`Test [ ] Aufgabe`); ein Klick hakt sie ab (`[x]`),
  Enter setzt die Aufgabenliste fort, `Shift+Enter` macht eine eingerückte Folgezeile (mehrzeiliger Punkt; ihr Text
  steht unter dem Text des Punkts – darin lassen sich auch einklappbare Blöcke anlegen).
  `- ` am Zeilenanfang wird als Aufzählungspunkt gezeichnet, `->`, `<-` und `<->` als Pfeile.
  In der Datei bleibt jeweils der getippte Text stehen.
- **Textfarben** (abschaltbar): `{rot|Text}` oder `{#1a73e8|Text}` – per F12 → „Textfarbe“ auf die Auswahl anwendbar.
- **Automatisches Färben:** Regeln aus Regex + Farbe. Voreingestellt: Datum, Uhrzeit, TODO/WICHTIG, #Tags.
- **Textbausteine mit Variablen:** `{date} {time} {datetime} {date_long} {date_iso} {time_s} {weekday}
  {weekday_short} {month_name} {year} {month} {day} {hour} {minute} {second} {week} {date+1} {date-1}
  {date:%d.%m.%y} {selection} {clipboard} {cursor} {filename} {user} {computer}`.
- **Frei belegbare Tastenkürzel** für Befehle, Bausteine, Formatierungen (`wrap:**|**`, `prefix:# `),
  Ersetzen in der Cursorzeile (`replace_line:[ ]|[x]` – erstes Vorkommen),
  Farben (`color:rot`) und Schalter (`toggle:markdown`).
- **Automatisches Einfügen** per Auslöser: `täglich`, `start`, `uhrzeit 12:00`, `datum 24.12.`, `wochentag Mo`;
  Position `oben`, `unten`, `cursor` oder `nach:Text` (hinter dem ersten Vorkommen von Text; steht er am Zeilenende, in die Zeile darunter – z.B. `nach:## Tagebuch`; nicht gefunden: oben). Voreinstellung: einmal täglich das Datum ganz oben.
- **Autosave** in die Notizdatei und gleichzeitig in beliebig viele weitere Dateien und **WebDAV**-Ziele (Cloud).
  Zusätzlich täglich eine Sicherungskopie `<datei>.bak`.
  F12 → „Speicherziele anzeigen“ listet Notizdatei, Datei-Kopien und WebDAV-Ziele; dort lassen sie sich
  bearbeiten, entfernen, im Dateimanager zeigen, testen (WebDAV) oder neu anlegen.
- **Kalender (CalDAV, nur lesen):** F12 → „Kalender verbinden“ (Kalender-Adresse, Benutzer, Passwort – z.B. Nextcloud
  `…/remote.php/dav/calendars/NAME/personal/`; oder nur der Server wie `https://caldav.fastmail.com/` – dann werden alle Kalender des Kontos gelesen). Neue Variablen für Bausteine und automatisches Einfügen:
  `{termin}` (nächster Termin), `{termine_heute}`, `{termine_woche}` (Montag bis Sonntag; je Termin eine Zeile mit Checkbox `[ ] …`). Nur die Titel (ohne Uhrzeit und Ort): `{termin_titel}`, `{termine_heute_titel}`, `{termine_woche_titel}`. Wiederkehrende Termine löst der
  Server auf; geladen wird beim Start und alle 15 Minuten, zwischengespeichert für offline. Steht als `caldav = …` in der Notizdatei.
- **Sprache / Language:** Deutsch oder Englisch – F12 → „Sprache“. Die Einstellung steht in der Notizdatei (`language = de|en`)
  und gilt damit auch am Handy. Neue Notizen starten in der Sprache des Systems. Englisch übersetzt sind Befehle, Meldungen,
  Hilfe, Datums- und Kalendertexte sowie die Kommentare im Einstellungsteil der Notiz.
- **Fensterlage:** Jedes Fenster öffnet sich dort und in der Größe, wo es zuletzt war – im Vollbild, wenn es zuletzt im Vollbild war, und unter Windows auf dem virtuellen Desktop, auf dem es zuletzt lag – auch beim Autostart und beim
  Wiederherstellen mehrerer Fenster. Gemerkt wird pro Notizdatei auf dem jeweiligen PC (fehlt ein Monitor, bleibt das Fenster auf dem Hauptbildschirm).
- **Weitermachen:** Beim Start steht der Cursor am Ende der zuletzt geänderten Zeile (abschaltbar).
- **Drucken** (Strg+P bzw. F12 → „Drucken“): öffnet eine formatierte Druckansicht im Standardbrowser, der
  sofort den Druckdialog zeigt (dort auch „Als PDF speichern“). Bei Markierung nur die Auswahl;
  „Drucken mit Zeitstempeln“ setzt das Änderungsdatum jeder Zeile an den Rand.
- **Infobereich** (Windows, optional): F12 → „Schließen (X) blendet ins Symbol im Infobereich aus“ – das Fenster
  verschwindet beim Schließen neben die Uhr und läuft weiter; ein Klick auf das Symbol holt es zurück,
  „Beenden“ im Menü des Symbols (oder F12 → „Dieses Fenster schließen“) beendet wirklich. Minimieren funktioniert normal.
- **Einklappbare Blöcke:** Zeilen markieren, `Strg+.` (oder F12 → „Block erstellen“), Titel eingeben. In der Datei steht dann
  `::: Titel` … die Zeilen … `:::`. Blöcke sind eingeklappt; Dreieck links, „⋯ n Zeilen“ oder `Strg+.` klappt auf und zu. Eingerückte Blöcke: `Tab`/`Shift+Tab` auf der Überschrift rückt den ganzen Block ein bzw. aus, eingefügte Zeilen bekommen die Einrückung des Blocks. In der formatierten Ansicht ist das abschließende `:::` aufgeklappter Blöcke unsichtbar (in der Klartext-Ansicht `Strg+M` sichtbar).
  F12 → „Alle Blöcke einklappen/ausklappen“, „Block auflösen“. Was aufgeklappt ist, merkt sich jeder PC selbst.
  Der Text in Blöcken kann automatisch eine eigene Farbe bekommen: F12 → „Farbe des Textes in einklappbaren Blöcken“ (`color_block`),
  die Titelzeilen über F12 → „Farbe der Blocküberschriften“ (`color_block_title`).
  Wird beim Erstellen der Vorschlag (erste markierte Zeile) als Titel übernommen, wird diese Zeile selbst zur Titelzeile.
- **Farben der Markdown-Elemente:** Überschriften, Links, Trennlinien, Aufzählungszeichen, Checkboxen, Zitate, Code und Pfeile
  lassen sich einfärben – F12 → „Farbe der …“ (`color_heading`, `color_link`, `color_rule`, `color_list`, `color_checkbox`,
  `color_quote`, `color_code`, `color_arrow`; leer = Standard). Dicke Trennlinien (`===`) haben eine eigene Farbe
  (`color_rule_thick`; leer = wie die dünnen).
- **Markdown bearbeiten:** In der formatierten Ansicht zählt jedes Element (Checkbox, Aufzählungspunkt, Pfeil, Link, ausgeblendete
  Zeichen) für den Cursor als ein Zeichen – Pfeiltasten springen darüber, Rücktaste/Entf löschen es als Ganzes.
  Checkbox und Aufzählungspunkt schließen das Leerzeichen dahinter ein (`[ ] `, `- `). Eine Trennlinie ist ebenfalls ein Zeichen
  (`---` dünn, `===` dick). Wird der ganze sichtbare Text eines formatierten Elements gelöscht (Überschrift, Zitat, fett, Code,
  Farbe …), verschwindet auch der unsichtbare Markdown-Code.
  **Rechtsklick** auf eine Zeile zeigt sie vorübergehend als Klartext mit allen Zeichen (z.B. um Link-Adresse oder Farbe zu ändern);
  verlässt der Cursor die Zeile (oder Esc), ist sie wieder formatiert. Alles als Klartext: `Strg+M` bzw. F12 → „Markdown-Ansicht umschalten“.
- **Einzug beim Umbruch:** Lange Listenpunkte, Aufgaben und eingerückte Zeilen laufen beim Umbruch unter dem Text weiter.
- **Nach oben:** Beim Scrollen erscheint unten rechts kurz ein Pfeil, der an den Anfang springt.
- **Listen einrücken:** `Tab` / `Shift+Tab` rückt in Listen und Aufgaben die ganze Zeile ein bzw. aus.
- **Links:** `Strg+K` macht aus dem markierten Text einen Link `[Text](https://…)`. Ein lokaler Dateipfad als Adresse (auch in Anführungszeichen, z.B. `"Z:\scan\brief.pdf"` aus „Als Pfad kopieren“)
  wird zu `file:///Z:\scan\brief.pdf`; ein Klick öffnet die Datei mit dem zugehörigen Programm. Dateien aus dem
  Dateimanager ins Fenster ziehen fügt solche Links ein – die Einfügestelle folgt dabei der Maus –, mit dem Dateinamen als Linktext (`[brief.pdf](file:///…)`). Ebenso Webseiten aus dem Browser (Symbol links in der Adressleiste
  oder einen Link auf der Seite ins Fenster ziehen): eingefügt wird `[Seitentitel](https://…)` – den Titel liefert der
  Browser mit, sonst wird er von der Seite geholt (nur Windows; unter Linux reicht das System nur Dateien weiter).
- **Erledigte Aufgaben:** Farbe (`color_done`) und Durchstreichen (`strike_done`) über F12 → „erledigt“.
- **Autovervollständigung** (Standard: ein): Wortvorschläge aus dem eigenen Text; `Enter` übernimmt
  und setzt ein Leerzeichen, `Tab` übernimmt ohne Leerzeichen, `Esc` verwirft (dann macht `Enter` wieder eine neue Zeile).
- **Alle Einstellungen stehen in derselben Textdatei** (unten angehängt, im Editor ausgeblendet).
  F12 → „Alle Einstellungen als Text bearbeiten“ zeigt sie.

## Dateiformat

```text
[2026-11-12 08:46:33] Donnerstag, 12.11.2026
[2026-11-12 08:47:10] Erste Notiz
[===== F12 Notes Einstellungen - im Programm mit F12 aendern =====]
dark = aus
font_size = 16
...
```

Reines UTF-8. Zeilen ohne Zeitstempel (z.B. mit einem anderen Editor ergänzt) werden problemlos gelesen.
Wird die Datei extern geändert (z.B. durch Cloud-Sync), lädt F12 Notes sie neu, sofern keine ungespeicherten
Änderungen vorliegen.

## Hinweise

- WebDAV-Passwörter stehen verschleiert (`enc:…`) in der Notizdatei. Das schützt nur vor zufälligem Mitlesen,
  es ist keine Verschlüsselung – am besten ein App-Passwort verwenden.
- Es läuft immer nur eine Instanz; ein zweiter Start holt das vorhandene Fenster nach vorn.
- Steht kein OpenGL zur Verfügung (z.B. Remote-Desktop), startet das Programm automatisch mit DirectX/Vulkan neu.

## Android

Dieselbe Notizdatei wie am PC – auf dem Handy. Die App liest und schreibt das gleiche Dateiformat und nimmt am selben
Cloud-Abgleich (WebDAV) teil. Download: `android/F12Notes.apk` im Update-Repository; Updates über F12 → „Nach Updates suchen“.

### Bedienung

- Beim Öffnen **Lesemodus**: scrollen, lesen, Aufgaben abhaken – die Tastatur kommt erst beim ersten
  Tippen auf den Text (F12 → „Tastatur beim Öffnen zeigen“ schaltet das um).
- Einfach schreiben. Gespeichert wird automatisch; mit der Cloud abgeglichen wird erst nach einer kurzen
  Tipp-Pause (Tippen hat Vorrang).
- **F12-Knopf** unten rechts (bzw. Taste F12 / Strg+F an einer Tastatur): Suchfeld für Text,
  Befehle, Bausteine und Einstellungen. Die Randfarbe des Knopfes zeigt den Cloud-Abgleich
  (blau = aktuell, grau = wird abgeglichen, orange = offline).
- Markdown wie am PC: Überschriften, fett/kursiv, Listen, `[ ]`-Aufgaben (antippen zum Abhaken),
  Pfeile, Trennlinien, Zitate, Codeblöcke, Textfarben `{rot|Text}`, Farbregeln.
- Beim Scrollen mit dem Finger wird das Änderungsdatum der obersten Zeile eingeblendet.
- **Cloud:** F12 → „Cloud verbinden (WebDAV)“ – dieselbe Adresse wie am PC angeben
  (die Datei, z.B. `…/F12Notes.txt`). Liegt dort schon eine Notiz, wird sie geladen oder mit
  dem Text des Handys zusammengeführt. Abgeglichen wird beim Öffnen, nach jedem Speichern
  und alle 30 Sekunden.
- **Einklappbare Blöcke:** Zeilen markieren → im Markierungsmenü „Block“ (oder F12 → „Einklappbaren Block
  erstellen“), Titel eingeben. Blöcke sind eingeklappt; das Dreieck am Rand, „⋯ n Zeilen“ oder – im Lesemodus –
  die Titelzeile antippen klappt auf und zu. In der Datei steht `::: Titel` … `:::` (wie am PC). Das abschließende `:::` ist in der formatierten Ansicht unsichtbar. Einrücken der Überschrift nimmt den ganzen Block mit.
  F12 → „Farbe der Blöcke“ gibt dem Text in allen Blöcken automatisch eine Farbe, „Farbe der Blocküberschriften“ den Titelzeilen.
- F12 → „Farben der Markdown-Elemente“: Überschriften, Links, Trennlinien, dicke Trennlinien (`===`), Listen, Checkboxen,
  Zitate, Code, Pfeile.
- Lange Listenpunkte und eingerückte Zeilen laufen beim Umbruch unter dem Text weiter.
- Beim Scrollen erscheint kurz ein ↑ über dem F12-Knopf: springt an den Anfang.
- Links antippen öffnet sie im Browser.
- **Markdown bearbeiten:** lange auf eine Zeile drücken – sie erscheint vorübergehend als Klartext mit allen Zeichen
  (Link-Adresse, Farbe … ändern). In der formatierten Ansicht zählt jedes Element (Checkbox, Pfeil, Link …) als ein Zeichen. Alles als Klartext:
  F12 → „Markdown-Ansicht umschalten“.
- **Mehrzeilige Listenpunkte:** F12 → „Neue Zeile im Listenpunkt“ (an einer Tastatur `Shift+Enter`) macht eine eingerückte
  Folgezeile ohne neue Checkbox; ihr Text steht unter dem Text des Punkts. Auch eingerückte Zeilen lassen sich zu Blöcken machen.
- Links auf Dateien am PC (`file:///Z:\…`) werden angezeigt; antippen öffnet sie nicht (die Datei liegt am PC).
- F12 → „Link einfügen“, „Einrücken“/„Ausrücken“ (an einer Tastatur auch `Strg+K`, `Tab`/`Shift+Tab`),
  „Farbe erledigter Aufgaben“.
- **Kalender (CalDAV, nur lesen):** F12 → „Kalender verbinden“ (Kalender-Adresse, Benutzer, Passwort – dieselbe wie am PC,
  z.B. Nextcloud `…/remote.php/dav/calendars/NAME/personal/`; oder nur der Server wie `https://caldav.fastmail.com/` –
  dann werden alle Kalender des Kontos gelesen). Danach in Bausteinen und beim automatischen Einfügen:
  `{termin}`, `{termine_heute}`, `{termine_woche}` (nur die Titel ohne Uhrzeit: `{termin_titel}`, `{termine_heute_titel}`, `{termine_woche_titel}`); F12 → „Nächsten Termin / Termine von heute / Termine dieser Woche einfügen“.
  Geladen beim Start und alle 15 Minuten, zwischengespeichert für offline.
- **Sprache / Language:** F12 → „Sprache“ (Deutsch oder English); steht in der Notiz und gilt auch am PC. Neue Notizen starten in der Sprache des Handys.
- Einstellungen mit dem Vermerk **Gerät** gelten nur für dieses Handy (Design, Schrift),
  solche mit **Notiz** stehen in der Notizdatei und gelten auch am PC (Markdown, Farbregeln,
  Bausteine, automatisches Einfügen).

### Unterschiede zur PC-Fassung

- Die Notiz liegt im geschützten Speicher der App; der Austausch läuft über die Cloud
  (WebDAV) sowie über „Notizdatei importieren“ / „Sicherungskopie speichern“.
- Eine Notiz je Gerät (keine mehreren Fenster), kein Drucken, keine frei belegbaren Tastenkürzel.
- Wortvorschläge kommen von der Bildschirmtastatur.
- Updates: F12 → „Nach Updates suchen“ öffnet den Download der neuen APK im Browser.
