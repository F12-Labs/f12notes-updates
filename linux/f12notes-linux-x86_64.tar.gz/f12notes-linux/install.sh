#!/bin/sh
# Installiert oder aktualisiert F12 Notes für den aktuellen Benutzer (kein sudo nötig).
#
#   Programm und neue Notizen:  ~/F12Notes/
#   Aufruf im Terminal:         f12notes   (Verknüpfung in ~/.local/bin)
#   Startmenü:                  Zubehör → F12 Notes
#
# Deinstallieren: ./install.sh --entfernen   (Notizdateien bleiben erhalten)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/F12Notes"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"
ICONS="$HOME/.local/share/icons/hicolor/256x256/apps"

if [ "$1" = "--entfernen" ]; then
    rm -f "$APP/f12notes" "$APP/f12notes.png" "$BIN/f12notes" "$APPS/f12notes.desktop" \
          "$ICONS/f12notes.png" "$HOME/.config/autostart/f12notes.desktop"
    rmdir "$APP" 2>/dev/null || true
    echo "F12 Notes wurde entfernt. Notizdateien bleiben erhalten."
    exit 0
fi

mkdir -p "$APP" "$BIN" "$APPS" "$ICONS"

# Erst als Kopie ablegen, dann austauschen: funktioniert auch, wenn F12 Notes gerade läuft
cp "$HERE/f12notes" "$APP/.f12notes.neu"
chmod 755 "$APP/.f12notes.neu"
mv -f "$APP/.f12notes.neu" "$APP/f12notes"
cp "$HERE/f12notes.png" "$APP/f12notes.png"
cp "$HERE/f12notes.png" "$ICONS/f12notes.png"

# Aufruf über ~/.local/bin (ersetzt auch die Programmdatei älterer Installationen)
rm -f "$BIN/f12notes"
ln -s "$APP/f12notes" "$BIN/f12notes"

cat > "$APPS/f12notes.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=F12 Notes
GenericName=Notizen
Comment=Minimalistischer Logbuch- und Notiz-Editor
Exec="$APP/f12notes"
Icon=f12notes
Terminal=false
Categories=Utility;TextEditor;
StartupWMClass=f12notes
DESKTOP

# Autostart-Eintrag einer älteren Installation auf den neuen Ort umstellen
AUTO="$HOME/.config/autostart/f12notes.desktop"
if [ -f "$AUTO" ]; then
    sed -i "s|^Exec=.*|Exec=\"$APP/f12notes\"|" "$AUTO"
fi

update-desktop-database "$APPS" 2>/dev/null || true
gtk-update-icon-cache -f -t "$HOME/.local/share/icons/hicolor" 2>/dev/null || true
echo "F12 Notes ist installiert in $APP"
echo "Start: Startmenü → Zubehör → F12 Notes  (oder im Terminal: f12notes)"
if pgrep -x f12notes >/dev/null 2>&1; then
    echo "Hinweis: F12 Notes läuft noch – die neue Version gilt nach dem nächsten Start."
fi
